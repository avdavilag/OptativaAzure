import requests, json


subscription_key = '35743f81b19545ce8fff99f1ba26b5c6'
endpoint = "https://southcentralus.api.cognitive.microsoft.com/"

def get_PhotoMessague(imaageUrl):
    vision_service_address = endpoint+'/vision/v3.2/'
    constructed_url = vision_service_address +"ocr"

    parameters={'language':"es"
    }

    imagepath=imaageUrl
    headers = {
            'Ocp-Apim-Subscription-Key': subscription_key,
            'Content-Type': 'application/json'
            #        'Content-Type': 'application/json'
            }

    body= {
            'url':imagepath
            }




    response = requests.post(constructed_url,params=parameters,headers=headers, json=body)
    
    response.raise_for_status()
    result = response.json()
    return result
